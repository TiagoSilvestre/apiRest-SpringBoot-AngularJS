package com.testebetha.apirest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.repository.query.Param;

import com.testebetha.apirest.models.Servico;

public interface ServicoRepository extends JpaRepository<Servico, Long> {

	Servico findById(long id);
	
    List<Servico> findByEstagio(@Param("estagio") String estagio);	
}

