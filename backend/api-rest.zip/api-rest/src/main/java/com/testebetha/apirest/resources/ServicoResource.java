package com.testebetha.apirest.resources;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.testebetha.apirest.models.Servico;
import com.testebetha.apirest.repository.ServicoRepository;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value="/api")
@Api(value="API REST Serviços")
@CrossOrigin(origins="*")
public class ServicoResource {

	@Autowired
	ServicoRepository servicoRepository;
	
	@ApiOperation(value="Retorna a lista de serviços")
	@GetMapping("/servicos")
	public List<Servico> listarServicos(@RequestParam(required = false) String estagio) {
		if (estagio != null) {
			return servicoRepository.findByEstagio(estagio);
		}
		return servicoRepository.findAll();
	}	
	
	@GetMapping("/servico/{id}")
	@ApiOperation(value="Retorna os dados de um serviço pelo id")
	public Servico listarServicoUnico(@PathVariable(value="id") long id) {
		return servicoRepository.findById(id);
	}	

	
	@PostMapping("/servico")
	@ApiOperation(value="Salva um serviço")
	public Servico salvarServico(@RequestBody Servico servico) {
		return servicoRepository.save(servico);
	}	

}
